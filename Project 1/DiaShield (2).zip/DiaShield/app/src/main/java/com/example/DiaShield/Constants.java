package com.example.DiaShield;

public class Constants {
    public static final String H_RATE = "HeartRate";
    public static final String R_RATE = "RespiratoryRate";
    public static final String TIMESTAMP = "timestamp";

}
